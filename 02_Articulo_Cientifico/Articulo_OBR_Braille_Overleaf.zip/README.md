# Artículo OBR Braille — Overleaf (3 páginas, 2 columnas)

## Contenido
- `articulo.tex`: artículo científico de 3 páginas, A4, dos columnas.
- `referencias.tex`: 14 referencias en formato APA 7, con sangría francesa manual.
- `README.md`: este archivo.

## Cómo subirlo a Overleaf
1. Descarga el ZIP de este proyecto.
2. En Overleaf: **New Project → Upload Project** y selecciona el ZIP.
3. El proyecto incluye `latexmkrc`, que configura XeLaTeX automáticamente. Si Overleaf no lo aplica, ve a **Menú → Compiler → XeLaTeX**.
4. Compila con **Recompile** dos veces para actualizar la paginación.
5. Para editar con tu compañero: **Share → Link sharing → Edit**.

## Notas
- El artículo está ajustado para ocupar **3 páginas**. Si al compilar pasa a 4, reduce ligeramente el tamaño de fuente o los márgenes en el preámbulo.
- La bibliografía es **manual**: edita directamente `referencias.tex`.
- La Tabla 1 está dentro de una columna y usa `tabularx`.
- El artículo usa Times New Roman si está disponible; si no, TeX Gyre Termes.
