# Proyecto OBR Braille — Overleaf (APA 7)

## Contenido
- `main.tex`: documento principal del proyecto (APA 7, una columna, doble espacio).
- `referencias.tex`: 22 referencias en formato APA 7, con sangría francesa manual.
- `README.md`: este archivo.

## Cómo subirlo a Overleaf
1. Descarga el ZIP de este proyecto.
2. En Overleaf: **New Project → Upload Project** y selecciona el ZIP.
3. El proyecto incluye `latexmkrc`, que configura XeLaTeX automáticamente. Si Overleaf no lo aplica, ve a **Menú → Compiler → XeLaTeX**.
4. Compila con **Recompile** dos veces para actualizar el índice y la paginación.
5. Para editar con tu compañero: **Share → Link sharing → Edit**.

## Notas
- La bibliografía es **manual**: edita directamente `referencias.tex`.
- La Tabla 1 se presenta en una página horizontal (landscape) por su ancho.
- La portada conserva el nombre del docente: `Ing. Raul Donato Cruz Huacac`.
- El documento usa Times New Roman si está disponible; si no, TeX Gyre Termes.
- Si Overleaf muestra un aviso de fuente, no impide la compilación.
